
import javax.swing.JFrame;

import javax.swing.JPanel;

import java.awt.Color;

import javax.swing.UIManager;

import javax.swing.JButton;

import java.awt.Font;

import java.awt.event.ActionListener;

import java.awt.event.ActionEvent;

import javax.swing.JLabel;

 

public class HOMEUI extends JFrame {

 

              /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
			private JPanel contentPane;

 

              /**

              * Launch the application.

              */
              /**

              * Create the frame.

              */

              public HOMEUI() {

                           setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

                           setBounds(100, 100, 738, 538);

                           contentPane = new JPanel();

                           contentPane.setBackground(Color.ORANGE);

                           contentPane.setForeground(Color.ORANGE);

                           contentPane.setBorder(UIManager.getBorder("EditorPane.border"));

                           setContentPane(contentPane);

                           contentPane.setLayout(null);

                          

                           JButton btnNewButton = new JButton("BUY_PRODUCTS");

                           btnNewButton.addActionListener(new ActionListener() {

                                         public void actionPerformed(ActionEvent e) {

                                         }

                           });

                           btnNewButton.setBackground(Color.ORANGE);

                           btnNewButton.setForeground(Color.BLACK);

                           btnNewButton.setFont(new Font("Serif", Font.BOLD, 14));

                           btnNewButton.setBounds(294, 201, 178, 45);

                           contentPane.add(btnNewButton);

                           btnNewButton.addActionListener(new ActionListener() {
                   			public void actionPerformed(ActionEvent e) {
                   			
                   	
                   			}
                   		});
                          

                           JButton btnNewButton_1 = new JButton("COMPLAINTS");

                           btnNewButton_1.setBackground(Color.ORANGE);

                           btnNewButton_1.setFont(new Font("Serif", Font.BOLD, 14));

                           btnNewButton_1.addActionListener(new ActionListener() {

                                         public void actionPerformed(ActionEvent e) {

                                        	 new Complaint();
                                         }

                           });

                           btnNewButton_1.setBounds(121, 197, 150, 53);

                           contentPane.add(btnNewButton_1);

                          

                           JButton btnNewButton_2 = new JButton("FEEDBACK");

                           btnNewButton_2.setBackground(Color.ORANGE);

                           btnNewButton_2.setForeground(Color.BLACK);

                           btnNewButton_2.setFont(new Font("Serif", Font.BOLD, 14));

                           btnNewButton_2.setBounds(506, 197, 139, 53);

                           contentPane.add(btnNewButton_2);

                           btnNewButton_2.addActionListener(new ActionListener() {
                      			public void actionPerformed(ActionEvent e) {
                      			
                      					new Feedback();
                      			}
                      		});

                           JLabel lblNewLabel = new JLabel("WELCOME TO M&M STOCK MANAGEMENT");

                           lblNewLabel.setFont(new Font("Papyrus", Font.BOLD, 19));

                           lblNewLabel.setBounds(110, 54, 547, 75);

                           contentPane.add(lblNewLabel);
                           setVisible(true);

              }
}

 

