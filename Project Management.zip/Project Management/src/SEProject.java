import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.GridLayout;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JPasswordField;
import java.awt.Color;

public class SEProject extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textField;
	private JPasswordField passwordField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					SEProject frame = new SEProject();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public SEProject() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 375, 233);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		contentPane.setLayout(new BorderLayout(0, 0));
		setContentPane(contentPane);
		
		JPanel panel = new JPanel();
		contentPane.add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(24, 16, 0, 0);
		panel.add(panel_1);
		panel_1.setLayout(new GridLayout(1, 0, 0, 0));
		
		JLabel lblUsername = new JLabel("UserName");
		lblUsername.setBounds(29, 8, 103, 16);
		panel.add(lblUsername);
		
		textField = new JTextField();
		textField.setBounds(164, 5, 116, 22);
		panel.add(textField);
		textField.setColumns(10);
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setBounds(26, 35, 106, 16);
		panel.add(lblPassword);
		JLabel label = new JLabel("");
		label.setForeground(Color.RED);
		label.setBounds(49, 128, 231, 16);
		panel.add(label);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(164, 32, 116, 22);
		panel.add(passwordField);
		JButton btnLogin = new JButton("Login");
		btnLogin.setBounds(52, 72, 80, 25);
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.println("HI ");
				String s=textField.getText();
				String s1=new String(passwordField.getPassword());
				if(s.equals("vasavi8182")&&s1.equals("mm8182")) {
				
					label.setText("");
					System.out.println("Hello ");
					new HOMEUI();
				}
				else
				{
					label.setText("Invalid UserName/Password");
					
				}
	
			}
		});
		panel.add(btnLogin);
		
		JButton btnSignUp = new JButton("Sign Up");
		btnSignUp.setBounds(188, 72, 77, 25);
		panel.add(btnSignUp);
		
		
	}
}
